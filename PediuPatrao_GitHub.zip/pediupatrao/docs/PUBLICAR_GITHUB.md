# Publicar o PediuPatrão no GitHub

Este pacote já contém um repositório Git local, com commits e duas branches:

| Branch | Conteúdo |
| --- | --- |
| `main` | Versão-base do ZIP enviado |
| `feature/exclusao-usuarios` | Revisão com exclusão de ATENDENTE/GERENTE, auditoria, 53 testes e instruções de entrega |

A branch selecionada é `feature/exclusao-usuarios`. Ela contém a versão completa mais recente. A criação das branches e dos commits foi feita nesta preparação; não representa um histórico de commits que já existia no ZIP. Os commits usam a identidade de automação desta sessão.

## 1. Extrair e abrir o terminal

Extraia o ZIP em uma pasta nova e abra o PowerShell ou o terminal do VS Code dentro da pasta `pediupatrao`, onde está o `pom.xml`. Use a pasta inteira do pacote.

Com o Git instalado, confira:

```powershell
git status
git branch
```

O resultado deve mostrar a branch `feature/exclusao-usuarios` selecionada e nenhuma alteração pendente. Não é necessário executar `git init` nem criar outro commit para publicar esta versão.

## 2. Criar o repositório na sua conta

Acesse [Criar repositório no GitHub](https://github.com/new).

- Em **Owner**, escolha sua conta.
- Em **Repository name**, use `pediupatrao-atividade-m1` ou o nome exigido pelo professor.
- Escolha a visibilidade: público permite a consulta pelo professor sem convite; privado exige conceder acesso a ele.
- Deixe desmarcadas as opções de adicionar README, `.gitignore` e licença. Esses arquivos não devem ser criados pelo GitHub neste passo, pois o projeto já possui histórico local.
- Clique em **Create repository** e copie a URL HTTPS mostrada.

## 3. Enviar as duas branches

No terminal aberto na pasta do projeto, substitua `SEU_USUARIO` pelo seu usuário real. Se tiver escolhido outro nome de repositório, ajuste também esse trecho da URL:

```powershell
git remote add origin https://github.com/SEU_USUARIO/pediupatrao-atividade-m1.git
git push -u origin main
git push -u origin feature/exclusao-usuarios
```

Se for solicitado, conclua a autenticação do GitHub no navegador. Não coloque senhas ou tokens nesses comandos, nos arquivos ou no chat.

Se aparecer `remote origin already exists`, confira primeiro:

```powershell
git remote -v
```

Se a URL já for a do repositório que acabou de criar, execute apenas os dois comandos `git push`. Não use `--force` para resolver conflitos de uma publicação anterior.

## 4. Conferir e entregar

Abra o repositório no GitHub e selecione `feature/exclusao-usuarios` no seletor de branches. Confira se o arquivo `docs/VALIDACAO.md` mostra 53 testes e se a tela de usuários inclui a exclusão.

Envie ao professor o link do repositório e o link da branch que contém a versão revisada:

```text
https://github.com/SEU_USUARIO/pediupatrao-atividade-m1
https://github.com/SEU_USUARIO/pediupatrao-atividade-m1/tree/feature/exclusao-usuarios
```

Se a atividade exigir Pull Request, abra a comparação de `feature/exclusao-usuarios` para `main`. Selecione `main` como base e `feature/exclusao-usuarios` como branch de comparação. Sugestão de título: **Adiciona exclusão de usuários com auditoria**. O código completo está na branch de entrega mesmo antes de uma eventual integração à `main`.

## Próximos commits

Para atribuir as suas próximas alterações à sua conta, configure seu nome e o e-mail cadastrado no GitHub (ou o e-mail privado fornecido nas configurações do GitHub):

```powershell
git config user.name "Seu nome"
git config user.email "SEU_EMAIL_DO_GITHUB"
```

O `.gitignore` já exclui `.env`, arquivos compilados e logs. O `.env.example` contém apenas o modelo de configuração, sem senha preenchida.

## Alternativa com GitHub CLI

Se você já usa o comando `gh`, pode criar um repositório privado e enviar as branches sem passar pelo formulário do site. Use esta alternativa em vez dos passos 2 e 3, e execute dentro da pasta do projeto:

```powershell
gh auth login
gh auth setup-git
gh repo create pediupatrao-atividade-m1 --private --source=. --remote=origin
git push -u origin main
git push -u origin feature/exclusao-usuarios
gh repo edit --default-branch main
gh repo view --web
```

O comando cria o repositório na conta autenticada. Para um trabalho que precise ser público, escolha explicitamente `--public` no lugar de `--private` antes de executar. Se o repositório já existir, use a URL dele no procedimento manual em vez de tentar criá-lo novamente.

Referências: [código local no GitHub](https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github) e [criação de repositório com GitHub CLI](https://cli.github.com/manual/gh_repo_create).
