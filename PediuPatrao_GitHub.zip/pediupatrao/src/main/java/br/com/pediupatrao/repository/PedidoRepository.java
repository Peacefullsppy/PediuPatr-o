package br.com.pediupatrao.repository;
import br.com.pediupatrao.model.Pedido;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface PedidoRepository extends MongoRepository<Pedido, String> { org.springframework.data.domain.Page<Pedido> findAllByOrderByEntradaEmDesc(org.springframework.data.domain.Pageable pageable); }
