package br.com.pediupatrao.service;
import br.com.pediupatrao.dto.Formularios.*;
import br.com.pediupatrao.model.*;
import br.com.pediupatrao.repository.UsuarioRepository;
import br.com.pediupatrao.security.UsuarioAtual;
import br.com.pediupatrao.exception.*;
import java.util.*;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
@PreAuthorize("hasRole('ADMIN')")
public class UsuarioService {
    private final UsuarioRepository usuarios;
    private final PasswordEncoder encoder;
    private final UsuarioAtual atual;
    private final AuditoriaService auditoria;
    private final Clock clock;
    public UsuarioService(UsuarioRepository usuarios, PasswordEncoder encoder, UsuarioAtual atual, AuditoriaService auditoria, Clock clock) {
        this.usuarios=usuarios; this.encoder=encoder; this.atual=atual; this.auditoria=auditoria; this.clock=clock;
    }
    public List<UsuarioResumo> listar() { return usuarios.findByExcluidoEmIsNullOrderByNomeAsc().stream().map(UsuarioResumo::de).toList(); }
    @Transactional
    public UsuarioResumo criar(UsuarioForm dados) {
        if (usuarios.existsByLogin(dados.login())) throw new RegraNegocioException("Este login já foi utilizado. Escolha outro login.");
        if (dados.senha().getBytes(StandardCharsets.UTF_8).length > 72)
            throw new RegraNegocioException("A senha excede o limite de 72 bytes. Use menos caracteres.");
        var salvo=usuarios.insert(new Usuario(null,null,dados.login(),dados.nome().trim(),encoder.encode(dados.senha()),dados.perfil(),true,null));
        auditoria.registrar("INCLUSAO_USUARIO","USUARIO",salvo.id(),Map.of(),RetratosAuditoria.usuario(salvo),null);
        return UsuarioResumo.de(salvo);
    }
    @Transactional
    public UsuarioResumo alterarPerfil(String id, PerfilForm dados) {
        var antes=buscarCadastro(id);
        if (antes.login().equals(atual.obter().usuario()))
            throw new RegraNegocioException("Você não pode alterar o próprio perfil nem desativar sua conta por esta tela.");
        var salvo=usuarios.save(new Usuario(id,antes.versao(),antes.login(),antes.nome(),antes.senhaHash(),dados.perfil(),dados.ativo(),null));
        auditoria.registrar("ALTERACAO_USUARIO","USUARIO",id,RetratosAuditoria.usuario(antes),RetratosAuditoria.usuario(salvo),null);
        return UsuarioResumo.de(salvo);
    }
    @Transactional
    public void excluir(String id) {
        var antes=buscarCadastro(id);
        if (antes.login().equals(atual.obter().usuario()))
            throw new RegraNegocioException("Você não pode excluir a própria conta.");
        if (antes.perfil()==Perfil.ADMIN)
            throw new RegraNegocioException("Somente cadastros de ATENDENTE e GERENTE podem ser excluídos.");
        // O login fica reservado para não atribuir ações antigas a uma pessoa nova.
        // A conta sai da listagem e perde a senha; pedidos e eventos permanecem intactos.
        var salvo=usuarios.save(new Usuario(id,antes.versao(),antes.login(),antes.nome(),null,antes.perfil(),false,clock.instant()));
        auditoria.registrar("EXCLUSAO_USUARIO","USUARIO",id,RetratosAuditoria.usuario(antes),RetratosAuditoria.usuario(salvo),
            "Exclusão do cadastro de " + antes.login() + " (" + antes.perfil() + ").");
    }
    private Usuario buscarCadastro(String id) {
        return usuarios.findById(id).filter(u -> u.excluidoEm()==null)
            .orElseThrow(() -> new NaoEncontradoException("Usuário não encontrado ou já excluído."));
    }
}
